package classes;

import java.util.Date;

public class ConsultaMedica {

	private int id_consulta;
	private Paciente paciente;
	private Profissional profissional;
	private Date data_inicio;
	private Date data_fim;
	private double valorConsulta;

	public int getId_consulta() {
		return id_consulta;
	}

	public void setId_consulta(int id_consulta) {
		this.id_consulta = id_consulta;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public Profissional getProfissional() {
		return profissional;
	}

	public void setProfissional(Profissional profissional) {
		this.profissional = profissional;
	}

	public Date getData_inicio() {
		return data_inicio;
	}

	public void setData_inicio(Date data_inicio) {
		this.data_inicio = data_inicio;
	}

	public Date getData_fim() {
		return data_fim;
	}

	public void setData_fim(Date data_fim) {
		this.data_fim = data_fim;
	}

	public double getValorConsulta() {
		return valorConsulta;
	}

	public void setValorConsulta(double valorConsulta) {
		this.valorConsulta = valorConsulta;
	}

	public void cancelarConsulta() {

	}

	public void aceitarConsulta() {

	}

	public void rejeitarConsutla() {

	}

	public void marcarConsulta() {

	}

	public void relatorioPaciente() {

	}

	public void relatorioProfissional() {

	}

	public void finalizarConsulta() {

	}

}
