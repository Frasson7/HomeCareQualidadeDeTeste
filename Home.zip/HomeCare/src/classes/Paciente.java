package classes;

public class Paciente extends Usuario {

	public String nome;
	public String cpf;
	public int telefone;
	public String endereco;
	public String login;
	public String senha;
	public String confirmarSenha;

	public void cadastrarPaciente(String nome, String cpf, int telefone, String endereco, String login, String senha) {

		this.nome = nome;
		this.cpf = cpf;
		this.telefone = telefone;
		this.endereco = endereco;
		this.login = login;
		this.senha = senha;

	}
	
	@Override
	public String toString() {
		return nome + cpf + telefone + endereco + login + senha;
	}
}
