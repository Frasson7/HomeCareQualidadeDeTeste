package classes;

public class Profissional extends Usuario {

	public String nome;
	public String cpf;
	public int telefone;
	public String endereco;
	public int cref;
	public String login;
	public String senha;
	public String confirmarSenha;
	public String areaDeAtuacao;

	public void cadastrarProfissional(String nome, String cpf, int telefone, String endereco, int cref, String login,
			String senha, String areaDeAtuacao) {

		this.nome = nome;
		this.cpf = cpf;
		this.telefone = telefone;
		this.endereco = endereco;
		this.cref = cref;
		this.login = login;
		this.senha = senha;
		this.areaDeAtuacao = areaDeAtuacao;

	}

}
