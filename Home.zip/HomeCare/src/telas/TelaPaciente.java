package telas;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaPaciente extends JFrame {

	private JPanel contentPane;
	static TelaPaciente telaPaciente = new TelaPaciente();
	static TelaPesquisarProfissional telaPesquisarProfisional = new TelaPesquisarProfissional();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telaPaciente.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaPaciente() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 224, 335);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPaciente = new JLabel("Paciente");
		lblPaciente.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPaciente.setBounds(65, 42, 82, 16);
		contentPane.add(lblPaciente);
		
		JButton btnProcurarProfissional = new JButton("Procurar Profissional");
		btnProcurarProfissional.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				telaPaciente.setVisible(false);
				telaPesquisarProfisional.setVisible(true);
				
				
				
			}
		});
		btnProcurarProfissional.setBounds(12, 111, 183, 25);
		contentPane.add(btnProcurarProfissional);
		
		JButton btnRelatrioDeAtendimentos = new JButton("Relat\u00F3rio de Atendimentos");
		btnRelatrioDeAtendimentos.setBounds(12, 149, 183, 25);
		contentPane.add(btnRelatrioDeAtendimentos);
		
		JButton btnEditarCadastro = new JButton("Editar Cadastro");
		btnEditarCadastro.setBounds(12, 187, 183, 25);
		contentPane.add(btnEditarCadastro);
		
		JButton btnDeslogar = new JButton("Deslogar");
		btnDeslogar.setBounds(50, 248, 97, 25);
		contentPane.add(btnDeslogar);
	}

}
