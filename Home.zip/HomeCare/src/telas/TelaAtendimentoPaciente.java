package telas;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class TelaAtendimentoPaciente extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFieldDataAtendimento;
	private JTextField textFieldHoraAtendimento;
	private JTextField textFieldNomeProfissional;
	private JTextField textFieldValorProfissional;
	static TelaAtendimentoPaciente telaAtendimento = new TelaAtendimentoPaciente();
	static TelaPesquisarProfissional telaPaciente = new TelaPesquisarProfissional();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telaAtendimento.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaAtendimentoPaciente() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 368, 368);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSolicitaoDeAtendimento = new JLabel("Solicita\u00E7\u00E3o de Atendimento");
		lblSolicitaoDeAtendimento.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblSolicitaoDeAtendimento.setBounds(64, 53, 224, 35);
		contentPane.add(lblSolicitaoDeAtendimento);
		
		JLabel lblNomeProfissional = new JLabel("Nome Profissional");
		lblNomeProfissional.setBounds(12, 130, 115, 16);
		contentPane.add(lblNomeProfissional);
		
		JLabel lblValorCobrado = new JLabel("Valor Cobrado");
		lblValorCobrado.setBounds(12, 159, 115, 16);
		contentPane.add(lblValorCobrado);
		
		JLabel lblData = new JLabel("Data");
		lblData.setBounds(12, 188, 56, 16);
		contentPane.add(lblData);
		
		JLabel lblHora = new JLabel("Hora");
		lblHora.setBounds(12, 217, 56, 16);
		contentPane.add(lblHora);
		
		textFieldNomeProfissional = new JTextField();
		textFieldNomeProfissional.setEditable(false);
		textFieldNomeProfissional.setBounds(139, 127, 116, 22);
		contentPane.add(textFieldNomeProfissional);
		textFieldNomeProfissional.setColumns(10);
		
		textFieldValorProfissional = new JTextField();
		textFieldValorProfissional.setEditable(false);
		textFieldValorProfissional.setBounds(139, 156, 116, 22);
		contentPane.add(textFieldValorProfissional);
		textFieldValorProfissional.setColumns(10);
		
		textFieldDataAtendimento = new JTextField();
		textFieldDataAtendimento.setBounds(94, 188, 116, 22);
		contentPane.add(textFieldDataAtendimento);
		textFieldDataAtendimento.setColumns(10);
		
		textFieldHoraAtendimento = new JTextField();
		textFieldHoraAtendimento.setBounds(94, 214, 116, 22);
		contentPane.add(textFieldHoraAtendimento);
		textFieldHoraAtendimento.setColumns(10);
		
		JButton btnSolicitarConsulta = new JButton("Solicitar Consulta");
		btnSolicitarConsulta.setBounds(12, 280, 144, 25);
		contentPane.add(btnSolicitarConsulta);
		
		JButton btnCancelarSolicitao = new JButton("Cancelar Solicita\u00E7\u00E3o");
		btnCancelarSolicitao.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				telaPaciente.setVisible(true);
				telaAtendimento.setVisible(false);
			}
		});
		btnCancelarSolicitao.setBounds(180, 280, 154, 25);
		contentPane.add(btnCancelarSolicitao);
		
	}
}
