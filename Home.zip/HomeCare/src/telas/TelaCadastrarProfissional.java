package telas;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import classes.Profissional;

public class TelaCadastrarProfissional extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNome;
	private JTextField txtCpf;
	private JTextField txtTelefone;
	private JTextField txtEndereco;
	private JTextField txtCref;
	private JPasswordField pfSenha;
	private JPasswordField pfConfirmarSenha;
	private JTextField txtAreaDeAtuacao;
	static TelaCadastrarProfissional telaCadastrarProfissional = new TelaCadastrarProfissional();
	static TelaInicial telaInicial = new TelaInicial();
	static TelaPreCadastro telaPreCadastro = new TelaPreCadastro();
	private JTextField txtLogin;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telaCadastrarProfissional.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaCadastrarProfissional() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 465, 542);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JLabel lblCadastrarProfissional = new JLabel("Cadastrar Profissional");
		lblCadastrarProfissional.setHorizontalAlignment(SwingConstants.CENTER);
		lblCadastrarProfissional.setFont(new Font("Tahoma", Font.PLAIN, 20));

		JLabel lblNome = new JLabel("Nome");
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JLabel lblCpf = new JLabel("CPF");
		lblCpf.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JLabel lblTelefone = new JLabel("Telefone");
		lblTelefone.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JLabel lblEndereco = new JLabel("Endere\u00E7o");
		lblEndereco.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JLabel lblCref = new JLabel("CREF");
		lblCref.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JLabel lblConfirmarSenha = new JLabel("Confirmar Senha");
		lblConfirmarSenha.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JLabel lvlAreaDeAtuacao = new JLabel("\u00C1rea de Atua\u00E7\u00E3o");
		lvlAreaDeAtuacao.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JLabel lblLogin = new JLabel("Login");
		lblLogin.setFont(new Font("Tahoma", Font.PLAIN, 15));

		txtLogin = new JTextField();
		txtLogin.setColumns(10);

		txtAreaDeAtuacao = new JTextField();
		txtAreaDeAtuacao.setColumns(10);

		txtNome = new JTextField();
		txtNome.setColumns(10);

		txtCpf = new JTextField();
		txtCpf.setColumns(10);

		txtTelefone = new JTextField();
		txtTelefone.setColumns(10);

		txtEndereco = new JTextField();
		txtEndereco.setColumns(10);

		txtCref = new JTextField();
		txtCref.setColumns(10);

		pfSenha = new JPasswordField();

		pfConfirmarSenha = new JPasswordField();

		JButton btnCadastrar = new JButton("Cadastrar");
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				Profissional profissional = new Profissional();
				String nome = txtNome.getText();
				String cpf = txtCpf.getText();
				int telefone = Integer.parseInt(txtTelefone.getText());
				String endereco = txtEndereco.getText();
				int cref = Integer.parseInt(txtCref.getText());
				String senha = String.valueOf(pfSenha.getPassword());
				String confirmarSenha = String.valueOf(pfConfirmarSenha.getPassword());
				String areaDeAtuacao = txtAreaDeAtuacao.getText();
				String login = txtLogin.getText();

				if (senha.equals(confirmarSenha) && senha != "") {
					Profissional cadProf = new Profissional();

					try {
						cadProf.cadastrarProfissional(nome,cpf,telefone,endereco,cref,login,senha,areaDeAtuacao);
					} catch (Exception e) {
						e.printStackTrace();
					}


				} else {
					System.out.println("Senha incorreta, digite novamente!");
					pfSenha.setText("");
					pfConfirmarSenha.setText("");
				}

				System.out.println(profissional);

			}
		});
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				telaCadastrarProfissional.setVisible(false);
				telaPreCadastro.setVisible(true);
				
			}
		});

		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lvlAreaDeAtuacao)
					.addContainerGap(320, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(117)
					.addComponent(lblCadastrarProfissional)
					.addContainerGap(129, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblCpf)
						.addComponent(lblTelefone)
						.addComponent(lblEndereco)
						.addComponent(lblCref)
						.addComponent(lblNome)
						.addComponent(lblSenha)
						.addComponent(lblLogin)
						.addComponent(lblConfirmarSenha))
					.addPreferredGap(ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addComponent(pfConfirmarSenha)
						.addComponent(pfSenha)
						.addComponent(txtLogin)
						.addComponent(txtCref)
						.addComponent(txtEndereco)
						.addComponent(txtNome, GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
						.addComponent(txtCpf)
						.addComponent(txtTelefone)
						.addComponent(txtAreaDeAtuacao))
					.addGap(72))
				.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
					.addGap(76)
					.addComponent(btnCadastrar)
					.addGap(70)
					.addComponent(btnCancelar)
					.addContainerGap(123, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(22)
					.addComponent(lblCadastrarProfissional)
					.addGap(46)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblNome)
							.addGap(18)
							.addComponent(lblCpf)
							.addGap(18)
							.addComponent(lblTelefone)
							.addGap(18)
							.addComponent(lblEndereco)
							.addGap(18)
							.addComponent(lblCref))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(txtNome, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(txtCpf, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(txtTelefone, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(txtEndereco, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(txtCref, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lvlAreaDeAtuacao)
						.addComponent(txtAreaDeAtuacao, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblLogin)
						.addComponent(txtLogin, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblSenha)
						.addComponent(pfSenha, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(pfConfirmarSenha, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblConfirmarSenha))
					.addPreferredGap(ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCadastrar)
						.addComponent(btnCancelar))
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
	}
}
