package telas;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaPesquisarProfissional extends JFrame {

	private JPanel contentPane;
	private JTable tableProfissionais;
	static TelaPesquisarProfissional telaPesquisarProfissional = new TelaPesquisarProfissional();
	static TelaPaciente telaPaciente = new TelaPaciente();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telaPesquisarProfissional.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaPesquisarProfissional() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 478, 488);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPesquisarProfissional = new JLabel("Pesquisar Profissional");
		lblPesquisarProfissional.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPesquisarProfissional.setBounds(123, 77, 226, 22);
		contentPane.add(lblPesquisarProfissional);
		
		JRadioButton rdbtnFisioterapeuta = new JRadioButton("Fisioterapeuta");
		rdbtnFisioterapeuta.setBounds(143, 138, 127, 25);
		contentPane.add(rdbtnFisioterapeuta);
		
		JRadioButton rdbtnFonoaudiologo = new JRadioButton("Fonoaudi\u00F3logo");
		rdbtnFonoaudiologo.setBounds(12, 138, 127, 25);
		contentPane.add(rdbtnFonoaudiologo);
		
		tableProfissionais = new JTable();
		tableProfissionais.setBounds(12, 172, 436, 205);
		contentPane.add(tableProfissionais);
		
		JRadioButton rdbtnTecnicoDeEnfermagem = new JRadioButton("T\u00E9cnico de Enfermagem");
		rdbtnTecnicoDeEnfermagem.setBounds(270, 138, 178, 25);
		contentPane.add(rdbtnTecnicoDeEnfermagem);
		
		JButton btnMarcarAtendimento = new JButton("Marcar Atendimento");
		btnMarcarAtendimento.setBounds(22, 403, 168, 25);
		contentPane.add(btnMarcarAtendimento);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				telaPesquisarProfissional.setVisible(false);
				telaPaciente.setVisible(true);
				
			}
		});
		btnCancelar.setBounds(351, 403, 97, 25);
		contentPane.add(btnCancelar);
	}
}
