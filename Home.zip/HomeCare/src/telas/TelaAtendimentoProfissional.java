package telas;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class TelaAtendimentoProfissional extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaAtendimentoProfissional frame = new TelaAtendimentoProfissional();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaAtendimentoProfissional() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 410, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSolicitaoDeAtemdimento = new JLabel("Solicita\u00E7\u00E3o de Atemdimento");
		lblSolicitaoDeAtemdimento.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblSolicitaoDeAtemdimento.setBounds(103, 13, 236, 16);
		contentPane.add(lblSolicitaoDeAtemdimento);
		
		JLabel lblPaciente = new JLabel("Paciente");
		lblPaciente.setBounds(12, 65, 56, 16);
		contentPane.add(lblPaciente);
		
		JLabel lblData = new JLabel("Data");
		lblData.setBounds(12, 94, 56, 16);
		contentPane.add(lblData);
		
		JLabel lblHora = new JLabel("Hora");
		lblHora.setBounds(12, 123, 56, 16);
		contentPane.add(lblHora);
		
		JLabel lblEndereo = new JLabel("Endere\u00E7o");
		lblEndereo.setBounds(12, 152, 56, 16);
		contentPane.add(lblEndereo);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(103, 62, 177, 22);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setBounds(103, 91, 116, 22);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setEditable(false);
		textField_2.setBounds(103, 120, 116, 22);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setEditable(false);
		textField_3.setBounds(103, 149, 280, 22);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnAceitarSolicitao = new JButton("Aceitar Solicita\u00E7\u00E3o");
		btnAceitarSolicitao.setBounds(12, 215, 153, 25);
		contentPane.add(btnAceitarSolicitao);
		
		JButton btnRecusarSolicitao = new JButton("Recusar Solicita\u00E7\u00E3o");
		btnRecusarSolicitao.setBounds(219, 215, 164, 25);
		contentPane.add(btnRecusarSolicitao);
	}
}
