package telas;

import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import classes.Paciente;

public class TelaCadastrarPaciente extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtNome;
	private JTextField txtCpf;
	private JTextField txtTelefone;
	private JTextField txtEndereco;
	private JPasswordField pfConfirmarSenha;
	private JPasswordField pfSenha;
	private JTextField txtLogin;
	static TelaCadastrarPaciente telaCadastrarPaciente = new TelaCadastrarPaciente();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telaCadastrarPaciente.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaCadastrarPaciente() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 374, 435);
		JPanel contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JLabel lblCadastroPaciente = new JLabel("Cadastro Paciente");
		lblCadastroPaciente.setRequestFocusEnabled(false);
		lblCadastroPaciente.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblCadastroPaciente.setHorizontalTextPosition(SwingConstants.CENTER);
		lblCadastroPaciente.setHorizontalAlignment(SwingConstants.CENTER);
		lblCadastroPaciente.setFont(new Font("Tahoma", Font.PLAIN, 20));

		JLabel lblNome = new JLabel("Nome");
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JLabel lblCpf = new JLabel("CPF");
		lblCpf.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JLabel lblTelefone = new JLabel("Telefone");
		lblTelefone.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JLabel lblEndereco = new JLabel("Endere�o");
		lblEndereco.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setFont(new Font("Tahoma", Font.PLAIN, 15));

		JLabel lblConfirmarSenha = new JLabel("Confirmar Senha");
		lblConfirmarSenha.setFont(new Font("Tahoma", Font.PLAIN, 15));

		txtNome = new JTextField();
		txtNome.setColumns(10);

		txtCpf = new JTextField();
		txtCpf.setColumns(10);

		txtTelefone = new JTextField();
		txtTelefone.setColumns(10);

		txtEndereco = new JTextField();
		txtEndereco.setColumns(10);

		pfConfirmarSenha = new JPasswordField();

		pfSenha = new JPasswordField();
		
		
		JButton btnCancelar = new JButton("Cancelar");
		
		JLabel lblLogin = new JLabel("Login");
		lblLogin.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		txtLogin = new JTextField();
		txtLogin.setColumns(10);


		JButton btnCadastrar = new JButton("Cadastrar");
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Paciente paciente = new Paciente();
				String nome = txtNome.getText();
				String cpf = txtCpf.getText();
				int telefone = Integer.parseInt(txtTelefone.getText());
				String endereco = txtEndereco.getText();
				String login = txtLogin.getText();
				String senha = String.valueOf(pfSenha.getPassword());
				String confirmarSenha = String.valueOf(pfConfirmarSenha.getPassword());

				System.out.println(paciente);

				if (senha.equals(confirmarSenha) && senha != "") {
					Paciente cadPaciente = new Paciente();

					try {
						cadPaciente.cadastrarPaciente(nome, cpf, telefone, endereco, login, confirmarSenha);
						telaCadastrarPaciente.setVisible(false);
						
						
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					System.out.println("Senha Incorreta, digite novamente! ");
					pfSenha.setText("");
					pfConfirmarSenha.setText("");
				}


			}
		});

		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNome)
								.addComponent(lblCpf))
							.addGap(87)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
								.addComponent(txtNome)
								.addComponent(txtCpf, GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblEndereco)
									.addGap(66))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblTelefone)
									.addGap(69)))
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(txtTelefone, GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
								.addComponent(txtEndereco, GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE))))
					.addGap(477))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(93)
					.addComponent(lblCadastroPaciente)
					.addContainerGap(549, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(52)
					.addComponent(btnCadastrar)
					.addGap(64)
					.addComponent(btnCancelar)
					.addContainerGap(531, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblLogin)
					.addContainerGap(292, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblConfirmarSenha)
						.addComponent(lblSenha))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addComponent(txtLogin, Alignment.TRAILING)
						.addComponent(pfConfirmarSenha)
						.addComponent(pfSenha, GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE))
					.addContainerGap(477, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblCadastroPaciente)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNome)
						.addComponent(txtNome, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblCpf)
						.addComponent(txtCpf, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTelefone)
						.addComponent(txtTelefone, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblEndereco)
						.addComponent(txtEndereco, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblLogin)
						.addComponent(txtLogin, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblSenha)
						.addComponent(pfSenha, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblConfirmarSenha)
						.addComponent(pfConfirmarSenha, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(39)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCadastrar)
						.addComponent(btnCancelar))
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
	}
}
