package telas;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class TelaPreCadastro extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	static TelaInicial telaInicial = new TelaInicial();
	static TelaPreCadastro telaPreCadastro = new TelaPreCadastro();
	static TelaCadastrarPaciente telaCadastrarPaciente = new TelaCadastrarPaciente();
	static TelaCadastrarProfissional telaCadastrarProfissional = new TelaCadastrarProfissional();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telaPreCadastro.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaPreCadastro() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 290, 343);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnCadastrarPaciente = new JButton("Cadastrar Paciente");
		btnCadastrarPaciente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				telaCadastrarPaciente.setVisible(true);
				telaPreCadastro.setVisible(false);
			
			}
		});
		btnCadastrarPaciente.setBounds(47, 61, 174, 23);
		contentPane.add(btnCadastrarPaciente);
		
		JButton btnCadastrarProfissional = new JButton("Cadastrar Profissional");
		btnCadastrarProfissional.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				telaCadastrarProfissional.setVisible(true);
				telaPreCadastro.setVisible(false);
			}
		});
		btnCadastrarProfissional.setBounds(47, 168, 174, 23);
		contentPane.add(btnCadastrarProfissional);
		
		JLabel lblEstPrecisandoDe = new JLabel("Est\u00E1 precisando de atendimento domiciliar?");
		lblEstPrecisandoDe.setBounds(10, 11, 337, 14);
		contentPane.add(lblEstPrecisandoDe);
		
		JLabel lblSeCadastreComo = new JLabel("Se cadastre como nosso Paciente!");
		lblSeCadastreComo.setBounds(10, 36, 337, 14);
		contentPane.add(lblSeCadastreComo);
		
		JLabel lblProfissionalDaSade = new JLabel("Profissional da Sa\u00FAde procurando pacientes?");
		lblProfissionalDaSade.setBounds(10, 118, 337, 14);
		contentPane.add(lblProfissionalDaSade);
		
		JLabel lblCadastreseAqui = new JLabel("Cadastre-se aqui!");
		lblCadastreseAqui.setBounds(10, 143, 337, 14);
		contentPane.add(lblCadastreseAqui);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				telaInicial.setVisible(true);
				telaPreCadastro.setVisible(false);
				
			}
		});
		btnVoltar.setBounds(10, 270, 79, 23);
		contentPane.add(btnVoltar);
	}
}
