package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

public class Conexao {
	protected Connection conexao;
	protected PreparedStatement ps;

	public Conexao() {

	}

	public Connection getConexao() throws SQLException, ClassNotFoundException {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			conexao = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/mydb?useSSL=false", "root", "root");
			System.out.println("Conex�o deu certo!");

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return conexao;

	}

	public ResultSet getConsulta(String query) throws SQLException {
		ResultSet rs = null;
		rs = ps.executeQuery(query);
		return rs;

	}

	public void getUpdate(String query) throws SQLException {
		ps.executeUpdate(query);
	}

}
